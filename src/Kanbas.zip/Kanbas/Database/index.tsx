import courses from "./courses.json";
import modules from "./modules.json";
import assignments from "./assignments.json";
import people from "./people.json";
import users from "./users.json";
import enrollments from "./enrollments.json";
export { courses, modules, assignments, people, users, enrollments };
